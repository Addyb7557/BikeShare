# -*- coding: utf-8 -*-
"""
Created on Mon Aug 20 21:04:50 2018

@author: Addy
"""

import sys
import time
import pandas as pd
import numpy as np

CITY_DATA = { 'chicago': 'sample.csv',
              'new york city': 'new_york_city.csv',
              'washington': 'washington.csv' }

def get_filters():
    """
    Asks user to specify a city, month, and day to analyze.

    Returns:
        (str) city - name of the city to analyze
        (str) month - name of the month to filter by, or "all" to apply no month filter
        (str) day - name of the day of week to filter by, or "all" to apply no day filter
    """
    print('Hello! Let\'s explore some US bikeshare data!')
    
    # TO DO: get user input for city (chicago, new york city, washington). HINT: Use a while loop to handle invalid inputs
    """
    #option 1
    #-----------
    city = str(input("Enter the city?\n"))
    cities = ["chicago","new york city","washington"]
    if city in cities:
        # TO DO: get user input for month (all, january, february, ... , june)
        month = str(input("Enter the Valid month?\n"))
        months = ['january', 'february', 'march', 'april', 'may', 'june']
        if month in months:
            print("{} is valid month".format(month))
        else:
            print("{} is not valid month".format(month))
            
        # TO DO: get user input for day of week (all, monday, tuesday, ... sunday)
        day = str(input("Enter the day?\n"))
        days = ["all","monday","tuesday","wednesday","thursday","friday","saturday","sunday"]
        if day in days:
            print("Entered day is {}".format(day))
        else:
            print("Entered day is invalid")
    else:
        print("Enterd City name {} is not valid".format(city))
    """
    """
    #option 2
    #--------
    city = str(input("Enter the city?\n"))
    cities = ["chicago","new york city","washington"]
    month = str(input("Enter the month?\n"))
    months = ['january', 'february', 'march', 'april', 'may', 'june']
    day = str(input("Enter the day?\n"))
    days = ["all","monday","tuesday","wednesday","thursday","friday","saturday","sunday"]
    if city in cities:
        if month in months:
            if day in days:
                print("Entered City:{}, Month:{}, Day:{}".format(city,month,day))
                return city, month, day
                print('-'*40)
    else:
        print("Invalid inputs!")
        print('-'*40)
        
    """
    """
    #Option 3
    #--------
    city = str(input("Enter the city?\n"))
    cities = ["chicago","new york city","washington"]
    if city in cities:
        print("Entered City is {}".format(city))
        
    month = str(input("Enter the month?\n"))
    months = ['january', 'february', 'march', 'april', 'may', 'june']
    if month in months:
        print("Entered Month is {}".format(month))
        
    day = str(input("Enter the day?\n"))
    days = ["all","monday","tuesday","wednesday","thursday","friday","saturday","sunday"]
    if day in days:
        print("Entered Day is {}".format(day))
    """
    
    #Option 4
    #--------
    city = str(input("Enter city?\n"))
    cities = ["chicago","new york city","washington"]
    if city.upper().lower() not in cities:
        print("Invalid Input, Please run your code again...")
        sys.exit()  
        
      
    month = str(input("Enter the month?\n"))
    months = ['january', 'february', 'march', 'april', 'may', 'june']
    if month.upper().lower() not in months:
        print("Invalid Input, Please run your code again...")
        sys.exit()
       
    day = str(input("Enter the day?\n"))
    days = ["all","monday","tuesday","wednesday","thursday","friday","saturday","sunday"]
    if day.upper().lower() not in days:
        print("Invalid Input, Please run your code again...")
        sys.exit()
 
    
    print('-'*40)
    return city.title(), month.title(), day.title()
    
    """
    #option 5
    cities = ["Chicago","New York City","Washington"]
    months = ['January', 'February', 'March', 'April', 'May', 'June']
    days = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
    while True:
        try:
            city = cities.index(in8put('\nEnter City? (Chicago, New York City, Washington)\n'))
            month = months.index(input('\nEnter Month?(January, February, etc.)\n'))
            day = days.index(input('\nEnter(Monday, Tuesday, etc.)\n'))
            print('-'*40)
            return cities[city].title(), months[month].title(), days[day].title()
        except ValueError:
            print ("Your previous choice is not available. Please try again")
            
    """

def load_data(city, month, day):
    
    print("Information regarding City:{}, Month:{}, Day:{} is as below".format(city.title(),month.title(),day.title()))
    
    if city=="Chicago":
          filename = "chicago.csv"
          df = pd.read_csv(filename)
          df['Start Time'] =pd.to_datetime(df['Start Time'])
          df['month'] = df['Start Time'].dt.month
          df['day'] = df['Start Time'].dt.day
          df['hour'] = df['Start Time'].dt.hour
        
    elif city=="New York City":
          filename = "new york city.csv"
          df = pd.read_csv(filename)
          df['Start Time'] =pd.to_datetime(df['Start Time'])
          df['month'] = df['Start Time'].dt.month
          df['day'] = df['Start Time'].dt.day
          df['hour'] = df['Start Time'].dt.hour
    
    elif city=="Washington":
          filename = "washington.csv"
          df = pd.read_csv(filename)
          df['Start Time'] =pd.to_datetime(df['Start Time'])
          df['month'] = df['Start Time'].dt.month
          df['day'] = df['Start Time'].dt.day
          df['hour'] = df['Start Time'].dt.hour
         
    return df

def time_stats(df):
    """Displays statistics on the most frequent times of travel."""

    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()

    # TO DO: display the most common month
    popular_month = df['month'].mode()[0]

    # TO DO: display the most common day of week
    popular_day = df['day'].mode()[0]

    # TO DO: display the most common start hour
    popular_hour = df['hour'].mode()[0]
    
    print("Popular Month:{}\nPopular Day:{}\nPopular Hour:{}".format(popular_month,popular_day,popular_hour))


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def station_stats(df):
    """Displays statistics on the most popular stations and trip."""

    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    # TO DO: display most commonly used start station
    common_station = df['Start Station'].mode()[0]

    # TO DO: display most commonly used end station
    common_end_station = df['End Station'].mode()[0]

    # TO DO: display most frequent combination of start station and end station trip
    df['Combination'] = df['Start Station']+", "+df['End Station']
    combination = df['Combination'].mode()[0]
    
    print("Common station:{}\nCommon End Station:{}\nCommon Combination:{}".format(common_station,common_end_station,combination))

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""

    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    # TO DO: display total travel time
    travel_time = df['Trip Duration'].sum()
    # TO DO: display mean travel time
    mean_time = df['Trip Duration'].mean()
    
    print("Travel time:{}\nMean Time:{}\n".format(travel_time,mean_time))


    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

def user_stats(df,city):
    print('\nCalculating User Stats...\n')
    start_time = time.time()
    if city=="Chicago" or city=="New York City":
        common_year_birth = df['Birth Year'].mode()[0]
        count_birth = df['Birth Year'].value_counts()
        gender = df['Gender'].value_counts()

    # TO DO: Display earliest, most recent, and most common year of birth
    usertype = df['User Type'].value_counts()
    
    #early = df['Birth Year']
    #recent = df['Birth Year']
    if city=="Chicago" or city=="New York City":
        print("Count of User Type:\n{}\nCount of Gender:\n{}\nCommon Birth Year:\n{}".format(usertype,gender,common_year_birth))
        #print('-'*40)
        print("Counts of Birth Year\n{}".format(count_birth))
    else:
        print("Count of User Type:\n{}".format(usertype))
        #print('-'*40)
    
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)

"""
def user_stats(df):
    
    print('\nCalculating User Stats...\n')
    start_time = time.time()

    # TO DO: Display counts of user types
    usertype = df['User Type'].value_counts()

    # TO DO: Display counts of gender
    gender = df['Gender'].value_counts()

    # TO DO: Display earliest, most recent, and most common year of birth
    common_year_birth = df['Birth Year'].mode()[0]
    count_birth = df['Birth Year'].value_counts()
    #early = df['Birth Year']
    #recent = df['Birth Year']
    
    print("Count of User Type:\n{}\nCount of Gender:\n{}\nCommon Birth Year:\n{}".format(usertype,gender,common_year_birth))
    print('-'*40)
    print("Counts of Birth Year\n{}".format(count_birth))
    #print('-'*40)
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-'*40)
"""
def raw_data(city):
    #print("City is {}".format(city))
    choice = str(input("Do you wants to see data for city {}?(Please Enter yes or no)\n".format(city)))
    if choice.lower()=="yes":
        if city =="Chicago":
            x=1
            r = pd.read_csv("chicago.csv")
            columns=r.columns.tolist()
            for index, row in r.iterrows():
                for m in columns:
                    print(row[m],end='\t')
                print()
                if x%5==0:
                    more = str(input("Do you want more?(Please Enter yes or no)\n"))
                    if more.lower()!="yes":
                        print('-'*40)
                        break
                x=x+1
                
        elif city =="New York City":
            x=1
            r = pd.read_csv("new york city.csv")
            columns=r.columns.tolist()
            for index, row in r.iterrows():
                for m in columns:
                    print(row[m],end='\t')                
                print()
                if x%5==0:
                    more = str(input("Do you want more?(Please Enter yes or no)\n"))
                    if more.lower()!="yes":
                        print('-'*40)
                        break            
                x+=1
                
        elif city =="Washington":
            x=1
            r = pd.read_csv("washington.csv")
            columns=r.columns.tolist()
            for index, row in r.iterrows():
                for m in columns:
                    print(row[m],end='\t')                
                print()
                if x%5==0:
                    more = str(input("Do you want more?(Please Enter yes or no)\n"))
                    if more.lower()!="yes":
                        print('-'*40)
                        break            
                x+=1
        

def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)

        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df,city)
        raw_data(city)
        """
        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break
        """
        res = input("Would you like to restart? Please Enter yes or no.\n")
        if res.lower()!= 'yes':
            break
        
        
if __name__ == "__main__":
	main()
